// ── Backgrounds ───────────────────────────────────────────────────────────────
// Graphite — warm-neutral dark, like a high-end code editor or Figma dark mode
export const BG = {
  0: "#111111", // terminal (deepest)
  1: "#141414", // app base
  2: "#1A1A1A", // canvas
  3: "#1F1F1F", // ← PRIMARY panels
  4: "#282828", // borders / separation
  5: "#333333", // ← SECONDARY hover/active
};

// ── Borders ───────────────────────────────────────────────────────────────────
export const BORDER = {
  subtle: "rgba(255,255,255,.04)",
  base: "rgba(255,255,255,.07)",
  mid: "rgba(255,255,255,.12)",
  hi: "rgba(255,255,255,.20)",
} as const;

// ── Text ──────────────────────────────────────────────────────────────────────
export const TEXT = {
  primary: "rgba(242,242,242,.95)",
  secondary: "rgba(200,200,200,.72)",
  muted: "rgba(160,160,160,.52)",
  faint: "rgba(120,120,120,.35)",
  ghost: "rgba(90,90,90,.16)",
} as const;

// ── Semantic colours ──────────────────────────────────────────────────────────
export const SEM = {
  green: "#4ade80",
  greenDim: "#22c55e",
  greenBg: "rgba(74,222,128,.07)",
  greenBorder: "rgba(74,222,128,.16)",
  red: "#f87171",
  redDim: "#ef4444",
  redBg: "rgba(248,113,113,.07)",
  redBorder: "rgba(248,113,113,.16)",
  amber: "#fbbf24",
  amberDim: "#f59e0b",
  amberBg: "rgba(251,191,36,.07)",
  amberBorder: "rgba(251,191,36,.16)",
  blue: "#60a5fa",
  blueDim: "#3b82f6",
  blueBg: "rgba(96,165,250,.07)",
  blueBorder: "rgba(96,165,250,.16)",
  // ── Violet accent — Stackbox identity colour ─────────────────────────────
  violet: "#8B7CF6",
  violetBright: "#A99BFB",
  violetDim: "#6D5CE0",
  violetBg: "rgba(139,124,246,.08)",
  violetBorder: "rgba(139,124,246,.22)",
} as const;

// ── Shadows ───────────────────────────────────────────────────────────────────
export const SHADOW = {
  xs: "0 1px 4px rgba(0,0,0,.55)",
  sm: "0 2px 10px rgba(0,0,0,.65)",
  md: "0 8px 28px rgba(0,0,0,.75)",
  lg: "0 16px 52px rgba(0,0,0,.82)",
  xl: "0 28px 80px rgba(0,0,0,.90)",
  inner: "inset 0 1px 0 rgba(255,255,255,.04)",
  glow: "0 0 20px rgba(139,124,246,.12)",
} as const;

// ── Radius ────────────────────────────────────────────────────────────────────
export const RADIUS = {
  xs: "4px",
  sm: "8px",
  md: "10px",
  lg: "12px",
  xl: "16px",
  full: "9999px",
} as const;

// ── Flat token map (C) ────────────────────────────────────────────────────────
export const C = {
  bg0: BG[0],
  bg1: BG[1],
  bg2: BG[2],
  bg3: BG[3],
  bg4: BG[4],
  bg5: BG[5],

  border: BORDER.base,
  borderMd: BORDER.mid,
  borderHi: BORDER.hi,

  t0: TEXT.primary,
  t1: TEXT.secondary,
  t2: TEXT.muted,
  t3: TEXT.faint,
  t4: TEXT.ghost,

  green: SEM.green,
  greenDim: SEM.greenDim,
  greenBg: SEM.greenBg,
  greenBorder: SEM.greenBorder,

  red: SEM.red,
  redDim: SEM.redDim,
  redBg: SEM.redBg,
  redBorder: SEM.redBorder,

  amber: SEM.amber,
  amberDim: SEM.amberDim,
  amberBg: SEM.amberBg,
  amberBorder: SEM.amberBorder,

  blue: SEM.blue,
  blueDim: SEM.blueDim,
  blueBg: SEM.blueBg,
  blueBorder: SEM.blueBorder,

  // ── Violet accent ─────────────────────────────────────────────────────────
  violet: SEM.violet,
  violetBright: SEM.violetBright,
  violetDim: SEM.violetDim,
  violetBg: SEM.violetBg,
  violetBorder: SEM.violetBorder,

  // Legacy compat — teal remapped to violet
  teal: SEM.violetBright,
  tealBright: SEM.violet,
  tealDim: SEM.violetBg,
  tealBorder: SEM.violetBorder,
  tealText: SEM.violetBright,

  shadowXs: SHADOW.xs,
  shadowSm: SHADOW.sm,
  shadow: SHADOW.md,
  shadowLg: SHADOW.lg,
  shadowXl: SHADOW.xl,
  shadowGlow: SHADOW.glow,

  r1: RADIUS.xs,
  r2: RADIUS.sm,
  r3: RADIUS.md,
  r4: RADIUS.lg,
  r5: RADIUS.xl,
} as const;

// ── Typography ────────────────────────────────────────────────────────────────
export const MONO = "'JetBrains Mono','Cascadia Code','Fira Code','Consolas',monospace";
export const SANS = "'DM Sans','Outfit',-apple-system,'SF Pro Text',system-ui,sans-serif";

/** Font size scale in px */
export const FS = {
  xxs: 11,
  xs: 12,
  sm: 13,
  md: 14,
  base: 15,
  lg: 16,
  xl: 18,
  xxl: 20,
  h3: 22,
  h2: 26,
  h1: 34,
} as const;

// ── Spacing (4-pt grid) ───────────────────────────────────────────────────────
export const SP = {
  1: 2,
  2: 4,
  3: 6,
  4: 8,
  5: 10,
  6: 12,
  7: 14,
  8: 16,
  10: 20,
  12: 24,
  16: 32,
  20: 40,
} as const;

// ── Transition presets ────────────────────────────────────────────────────────
export const T = {
  fast: "all .08s ease",
  base: "all .12s ease",
  slow: "all .20s ease",
  spring: "all .18s cubic-bezier(.4,0,.2,1)",
  bounce: "all .22s cubic-bezier(.16,1,.3,1)",
} as const;

// ── App constants ─────────────────────────────────────────────────────────────
export const PORT = 7547;
export const STORAGE_KEY = "stackbox-runboxes-v2";