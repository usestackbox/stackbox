// ── Backgrounds — Charcoal palette ────────────────────────────────────────────
// #121212 Material Charcoal — deepest
// #1A1A1A Deep Charcoal      — main editor
// #2F4F4F Slate Charcoal     — headers/tabs
// #36454F Cool Charcoal      — sidebar/panels
export const BG = {
  0: "#121212",   // Material Charcoal — absolute base, deepest surfaces
  1: "#212629",   // Deep Charcoal — main editor background
  2: "#303437",   // between Deep and Slate — panel backgrounds
  3: "#2f4f4f",   // Slate Charcoal — tab bar, header bars
  4: "#36454f",   // Cool Charcoal — sidebar, secondary panels
  5: "#425860",   // lightened Cool Charcoal — hover / selected states
};

// ── Borders ───────────────────────────────────────────────────────────────────
export const BORDER = {
  subtle: "rgba(100,160,160,.07)",
  base:   "rgba(100,160,160,.13)",
  mid:    "rgba(100,160,160,.22)",
  hi:     "rgba(130,185,185,.32)",
} as const;

// ── Text ──────────────────────────────────────────────────────────────────────
export const TEXT = {
  primary:   "rgba(228,236,236,.95)",
  secondary: "rgba(178,200,200,.80)",
  muted:     "rgba(128,158,160,.60)",
  faint:     "rgba(90,120,122,.44)",
  ghost:     "rgba(60,90,92,.22)",
} as const;

// ── Semantic colours ──────────────────────────────────────────────────────────
export const SEM = {
  green: "#4dffaa",
  greenDim: "#28e882",
  greenBg: "rgba(77,255,170,.07)",
  greenBorder: "rgba(77,255,170,.16)",
  red: "#ff6b6b",
  redDim: "#f54242",
  redBg: "rgba(255,107,107,.07)",
  redBorder: "rgba(255,107,107,.16)",
  amber: "#ffd060",
  amberDim: "#f5a623",
  amberBg: "rgba(255,208,96,.07)",
  amberBorder: "rgba(255,208,96,.16)",
  // accent — desaturated teal pulled from Slate Charcoal lightened
  blue: "#5a9090",
  blueDim: "#417070",
  blueBg: "rgba(90,144,144,.08)",
  blueBorder: "rgba(90,144,144,.20)",
  // ── Calus accent — lighter teal derived from #2F4F4F ────────────────────────
  violet: "#6AACAC",
  violetBright: "#88C4C4",
  violetDim: "#4E8888",
  violetBg: "rgba(106,172,172,.09)",
  violetBorder: "rgba(106,172,172,.22)",
} as const;

// ── Shadows ───────────────────────────────────────────────────────────────────
export const SHADOW = {
  xs: "0 1px 4px rgba(0,0,0,.45)",
  sm: "0 2px 10px rgba(0,0,0,.54)",
  md: "0 8px 28px rgba(0,0,0,.60)",
  lg: "0 16px 52px rgba(0,0,0,.66)",
  xl: "0 28px 80px rgba(0,0,0,.72)",
  inner: "inset 0 1px 0 rgba(255,255,255,.05)",
  glow: "0 0 24px rgba(106,172,172,.12)",
} as const;

// ── Radius ────────────────────────────────────────────────────────────────────
export const RADIUS = {
  xs: "4px",
  sm: "8px",
  md: "10px",
  lg: "12px",
  xl: "16px",
  full: "9999px",
} as const;

// ── Flat token map (C) ────────────────────────────────────────────────────────
export const C = {
  bg0: BG[0],
  bg1: BG[1],
  bg2: BG[2],
  bg3: BG[3],
  bg4: BG[4],
  bg5: BG[5],

  border: BORDER.base,
  borderSubtle: BORDER.subtle,
  borderMd: BORDER.mid,
  borderHi: BORDER.hi,

  t0: TEXT.primary,
  t1: TEXT.secondary,
  t2: TEXT.muted,
  t3: TEXT.faint,
  t4: TEXT.ghost,

  green: SEM.green,
  greenDim: SEM.greenDim,
  greenBg: SEM.greenBg,
  greenBorder: SEM.greenBorder,

  red: SEM.red,
  redDim: SEM.redDim,
  redBg: SEM.redBg,
  redBorder: SEM.redBorder,

  amber: SEM.amber,
  amberDim: SEM.amberDim,
  amberBg: SEM.amberBg,
  amberBorder: SEM.amberBorder,

  blue: SEM.blue,
  blueDim: SEM.blueDim,
  blueBg: SEM.blueBg,
  blueBorder: SEM.blueBorder,

  violet: SEM.violet,
  violetBright: SEM.violetBright,
  violetDim: SEM.violetDim,
  violetBg: SEM.violetBg,
  violetBorder: SEM.violetBorder,

  // Legacy compat
  teal: SEM.violetBright,
  tealBright: SEM.violet,
  tealDim: SEM.violetBg,
  tealBorder: SEM.violetBorder,
  tealText: SEM.violetBright,

  shadowXs: SHADOW.xs,
  shadowSm: SHADOW.sm,
  shadow: SHADOW.md,
  shadowLg: SHADOW.lg,
  shadowXl: SHADOW.xl,
  shadowGlow: SHADOW.glow,

  r1: RADIUS.xs,
  r2: RADIUS.sm,
  r3: RADIUS.md,
  r4: RADIUS.lg,
  r5: RADIUS.xl,
} as const;

// ── Typography ────────────────────────────────────────────────────────────────
export const MONO = "'JetBrains Mono','Cascadia Code','Fira Code','Consolas',monospace";
export const SANS = "'DM Sans','Outfit',-apple-system,'SF Pro Text',system-ui,sans-serif";

/** Font size scale in px */
export const FS = {
  xxs: 11,
  xs: 12,
  sm: 13,
  md: 14,
  base: 15,
  lg: 16,
  xl: 18,
  xxl: 20,
  h3: 22,
  h2: 26,
  h1: 34,
} as const;

// ── Spacing (4-pt grid) ───────────────────────────────────────────────────────
export const SP = {
  1: 2,
  2: 4,
  3: 6,
  4: 8,
  5: 10,
  6: 12,
  7: 14,
  8: 16,
  10: 20,
  12: 24,
  16: 32,
  20: 40,
} as const;

// ── Transition presets ────────────────────────────────────────────────────────
export const T = {
  fast: "all .08s ease",
  base: "all .12s ease",
  slow: "all .20s ease",
  spring: "all .18s cubic-bezier(.4,0,.2,1)",
  bounce: "all .22s cubic-bezier(.16,1,.3,1)",
} as const;

// ── App constants ─────────────────────────────────────────────────────────────
export const PORT = 7547;
export const STORAGE_KEY = "calus-runboxes-v2";