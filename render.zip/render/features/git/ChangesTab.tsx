import { useState } from "react";
import { C, FS, MONO, SANS } from "../../design";
import type { AgentSpan, LiveDiffFile, WorktreeEntry } from "./types";

interface Props {
  files: LiveDiffFile[];
  agentSpans?: AgentSpan[];
  commitCount?: number;
  onFileClick?: (fc: LiveDiffFile) => void;
  worktrees?: WorktreeEntry[];
  selectedWorktreePath?: string | null;
  onWorktreeChange?: (path: string | null) => void;
  // compat — unused
  committing?: boolean;
  pushing?: boolean;
  message?: string;
  onMessage?: (m: string) => void;
  onCommit?: () => void;
  onCommitPush?: () => void;
  onPush?: () => void;
  onStage?: (path: string) => Promise<void>;
  onUnstage?: (path: string) => Promise<void>;
  onDiscard?: (path: string) => Promise<void>;
}

const INS_COL = C.green;
const DEL_COL = C.red;

// ── Stat badge  +17 • -0 ──────────────────────────────────────────────────────
function StatBadge({ ins, del }: { ins: number; del: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 3, flexShrink: 0 }}>
      <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: ins > 0 ? INS_COL : C.t3, fontWeight: 600 }}>
        +{ins}
      </span>
      <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: C.t3 }}>•</span>
      <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: del > 0 ? DEL_COL : C.t3, fontWeight: 600 }}>
        -{del}
      </span>
    </div>
  );
}

// ── Inline diff ───────────────────────────────────────────────────────────────
function InlineDiff({ diff }: { diff: string }) {
  const lines = diff.split("\n");
  return (
    <div style={{ borderTop: `1px solid ${C.border}`, overflowX: "auto", maxHeight: 360, overflowY: "auto" }}>
      <table style={{ borderCollapse: "collapse", width: "100%", tableLayout: "fixed" }}>
        <colgroup>
          <col style={{ width: 36 }} />
          <col style={{ width: 12 }} />
          <col />
        </colgroup>
        <tbody>
          {lines.map((line, i) => {
            const isAdd  = line.startsWith("+") && !line.startsWith("+++");
            const isDel  = line.startsWith("-") && !line.startsWith("---");
            const isHunk = line.startsWith("@@");
            const isMeta = !isAdd && !isDel && !isHunk &&
              (line.startsWith("+++") || line.startsWith("---") ||
               line.startsWith("diff ") || line.startsWith("index ") ||
               line.startsWith("new file") || line.startsWith("deleted file"));
            const rowBg  = isAdd ? "rgba(74,222,128,.05)" : isDel ? "rgba(248,113,113,.05)" : "transparent";
            const gutBg  = isAdd ? "rgba(74,222,128,.08)" : isDel ? "rgba(248,113,113,.08)" : "rgba(255,255,255,.01)";
            const sigCol = isAdd ? "rgba(74,222,128,.5)"  : isDel ? "rgba(248,113,113,.5)"  : "transparent";
            const txtCol = isAdd  ? "rgba(160,220,160,.85)"
                         : isDel  ? "rgba(220,155,155,.85)"
                         : isHunk ? "rgba(90,120,155,.55)"
                         : isMeta ? C.t3
                         : C.t2;
            return (
              <tr key={i} style={{ background: rowBg }}>
                <td style={{ padding: "0 6px", textAlign: "right", fontSize: 9, fontFamily: MONO, color: "rgba(255,255,255,.12)", userSelect: "none", background: gutBg, borderRight: `1px solid ${C.border}`, lineHeight: "17px", verticalAlign: "top" }}>
                  {!isMeta && !isHunk ? i + 1 : ""}
                </td>
                <td style={{ textAlign: "center", fontSize: 9, fontFamily: MONO, color: sigCol, userSelect: "none", background: gutBg, borderRight: `1px solid ${C.border}`, lineHeight: "17px", verticalAlign: "top" }}>
                  {isAdd ? "+" : isDel ? "−" : ""}
                </td>
                <td style={{ paddingLeft: 8, paddingRight: 6, lineHeight: "17px", verticalAlign: "top" }}>
                  <span style={{ fontSize: 11, color: txtCol, fontFamily: MONO, whiteSpace: "pre-wrap", wordBreak: "break-all", fontStyle: isHunk ? "italic" : "normal" }}>
                    {line || " "}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── File row ──────────────────────────────────────────────────────────────────
// Bug 2 changes:
//   • No chevron icon
//   • No per-file StatBadge (+N • -N)
//   • Diff is always expanded (no click needed)
//   • onMouseLeave resets to C.bg2 (was "transparent" → caused flicker)
function FileRow({ fc }: { fc: LiveDiffFile }) {
  const name = fc.path.split(/[/\\]/).pop() ?? fc.path;
  const dir  = fc.path.slice(0, fc.path.length - name.length);
  const hasDiff = !!fc.diff?.trim();

  return (
    <div style={{ border: `1px solid ${C.border}`, borderRadius: 10, overflow: "hidden", background: C.bg2 }}>
      {/* Row header — no chevron, no stat badge, no click handler */}
      <div
        style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "8px 12px",
          userSelect: "none",
        }}
        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = C.bg3; }}
        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = C.bg2; }}
      >
        {/* Path */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", alignItems: "baseline", gap: 5 }}>
          {dir && (
            <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: C.t3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 120 }}>
              {dir}
            </span>
          )}
          <span style={{ fontSize: FS.xs, fontFamily: MONO, color: C.t0, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {name}
          </span>
        </div>
      </div>

      {/* Diff always visible */}
      {hasDiff && <InlineDiff diff={fc.diff!} />}

      {!hasDiff && (
        <div style={{ padding: "8px 12px", borderTop: `1px solid ${C.border}`, fontSize: FS.xxs, color: C.t3, fontFamily: SANS }}>
          {fc.change_type === "deleted" ? "File deleted" : "Recomputing…"}
        </div>
      )}
    </div>
  );
}

// ── Worktree dropdown ─────────────────────────────────────────────────────────
function WorktreeDropdown({ worktrees, selectedPath, onChange }: {
  worktrees: WorktreeEntry[];
  selectedPath: string | null;
  onChange: (path: string | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const mainWt = worktrees.find(wt => wt.is_main);
  const nonMain = worktrees.filter(wt => !wt.is_main);
  const selected = selectedPath ? worktrees.find(wt => wt.path === selectedPath) : null;
  const label = selected
    ? (selected.branch.split("/").pop() ?? selected.branch)
    : (mainWt?.branch.split("/").pop() ?? mainWt?.branch ?? "main");

  return (
    <div style={{ position: "relative" }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          display: "flex", alignItems: "center", gap: 5,
          height: 22, padding: "0 8px",
          background: "transparent",
          border: `1px solid ${C.border}`,
          borderRadius: C.r1,
          color: C.t2, fontSize: FS.xxs, fontFamily: MONO,
          cursor: "pointer", transition: "all .1s",
        }}
        onMouseEnter={e => { const el = e.currentTarget as HTMLElement; el.style.borderColor = C.borderMd; el.style.color = C.t1; }}
        onMouseLeave={e => { if (!open) { const el = e.currentTarget as HTMLElement; el.style.borderColor = C.border; el.style.color = C.t2; } }}
      >
        {label}
        <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: open ? "rotate(180deg)" : "rotate(0)", transition: "transform .15s" }}>
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {open && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 99 }} onClick={() => setOpen(false)} />
          <div style={{ position: "absolute", top: "calc(100% + 4px)", right: 0, zIndex: 100, background: C.bg3, border: `1px solid ${C.borderMd}`, borderRadius: C.r2, boxShadow: C.shadowSm, minWidth: 150, padding: 3 }}>
            {[{ path: null, branch: mainWt?.branch ?? "main", sublabel: "main worktree" }, ...nonMain.map(wt => ({ path: wt.path, branch: wt.branch, sublabel: wt.path.split(/[/\\]/).slice(-2).join("/") }))].map(item => (
              <div
                key={item.path ?? "__main__"}
                onClick={() => { onChange(item.path); setOpen(false); }}
                style={{ padding: "5px 8px", borderRadius: 4, cursor: "pointer", background: selectedPath === item.path ? C.bg4 : "transparent", transition: "background .08s" }}
                onMouseEnter={e => { if (selectedPath !== item.path) (e.currentTarget as HTMLElement).style.background = C.bg3; }}
                onMouseLeave={e => { if (selectedPath !== item.path) (e.currentTarget as HTMLElement).style.background = "transparent"; }}
              >
                <div style={{ fontSize: FS.xs, fontFamily: MONO, color: C.t0 }}>{item.branch.split("/").pop()}</div>
                <div style={{ fontSize: FS.xxs - 1, fontFamily: MONO, color: C.t3 }}>{item.sublabel}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export function ChangesTab({
  files, commitCount, worktrees, selectedWorktreePath, onWorktreeChange,
}: Props) {
  const totalIns = files.reduce((s, f) => s + f.insertions, 0);
  const totalDel = files.reduce((s, f) => s + f.deletions,  0);
  const hasWorktrees = worktrees && worktrees.length > 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0 }}>

      {/* ── Header bar ── */}
      <div style={{
        padding: "0 12px", height: 38,
        display: "flex", alignItems: "center", gap: 10,
        borderBottom: `1px solid ${C.border}`, flexShrink: 0,
        background: C.bg1,
      }}>
        {/* Branch */}
        {hasWorktrees && onWorktreeChange ? (
          <WorktreeDropdown
            worktrees={worktrees!}
            selectedPath={selectedWorktreePath ?? null}
            onChange={onWorktreeChange}
          />
        ) : (
          <span style={{ fontSize: FS.xs, fontFamily: MONO, fontWeight: 600, color: C.t1 }}>main</span>
        )}

        {/* File count */}
        {files.length > 0 && (
          <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: C.t3 }}>
            {files.length} {files.length === 1 ? "file" : "files"}
          </span>
        )}

        <span style={{ color: C.t4, fontSize: FS.xxs, fontFamily: MONO }}>•</span>

        {/* +ins -del totals */}
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: totalIns > 0 ? INS_COL : C.t3, fontWeight: 600 }}>+{totalIns}</span>
          <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: C.t3 }}>-{totalDel}</span>
        </div>

        {/* Commit count */}
        {commitCount !== undefined && commitCount > 0 && (
          <>
            <span style={{ color: C.t4, fontSize: FS.xxs, fontFamily: MONO }}>•</span>
            <span style={{ fontSize: FS.xxs, fontFamily: MONO, color: C.t3 }}>
              {commitCount} {commitCount === 1 ? "commit" : "commits"}
            </span>
          </>
        )}
      </div>

      {/* ── File list ── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "8px", display: "flex", flexDirection: "column", gap: 3 }}>
        {files.length === 0 ? (
          <div style={{ padding: "52px 0", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={C.t3} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
            <span style={{ fontSize: FS.xs, color: C.t3, fontFamily: SANS }}>Working tree clean</span>
          </div>
        ) : (
          files.map(fc => <FileRow key={fc.path} fc={fc} />)
        )}
      </div>
    </div>
  );
}