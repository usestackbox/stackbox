// features/workspace/WorkspaceView.tsx
import { useState, useRef, useEffect, useCallback } from "react";
import { listen } from "@tauri-apps/api/event";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { C, SANS, MONO } from "../../design";
import { PanelHeader, ResizeHandle } from "../../ui";
import type { Runbox } from "../../types";
import type { DiffTab } from "../../types";
import { DiffViewer } from "../diff/DiffViewer";
import { TabBar }         from "./TabBar";
import { TabContextMenu } from "./TabContextMenu";
import {
  GAP, MIN_W, MIN_H, nextZ, tileWindows,
  type WinState, type FileTab, type SidePanel, type FilesView,
} from "./types";

const isMac = navigator.userAgent.toLowerCase().includes("mac");

interface WorkspaceViewProps {
  runbox:             Runbox;
  branch:             string;
  toolbarSlot?:       React.ReactNode;
  sidePanel?:         SidePanel;
  sidebarCollapsed?:  boolean;
  fileTreeOpen?:      boolean;
  contentMarginLeft?: number;
  onSidePanelToggle?: (panel: "files" | "git" | "memory") => void;
  onSidebarToggle?:   () => void;
  onFileTreeToggle?:  () => void;
  onCwdChange:        (cwd: string) => void;
  onSessionChange?:   (sid: string) => void;
  onOpenDiff:         (ref: { open: (fc: any) => void }) => void;
  onOpenFile?:        (ref: { open: (path: string) => void }) => void;
  /** Render slot for the floating browser panel overlay */
  browserPanelSlot?:  React.ReactNode;
  /** Render slot for terminal pane (receives win geometry + callbacks) */
  renderTermPane:     (win: WinState, callbacks: TermPaneCallbacks) => React.ReactNode;
  /** Render slot for browser pane */
  renderBrowsePane:   (win: WinState, pendingUrl: string | null, onConsumed: () => void) => React.ReactNode;
  /** Render file editor */
  renderFileEditor:   (tab: FileTab, onClose: () => void) => React.ReactNode;
  /** Render side panels */
  renderSidePanel:    (panel: SidePanel, runbox: Runbox, branch: string, onClose: () => void) => React.ReactNode;
  /** Called when user requests a new workspace */
  onNewWorkspace?:    () => void;
}

export interface TermPaneCallbacks {
  isActive:        boolean;
  onActivate:      () => void;
  onCwdChange:     (cwd: string) => void;
  onSessionChange: (sid: string) => void;
  onClose:         () => void;
  onMinimize:      () => void;
  onMaximize:      () => void;
  onDragStart:     (e: React.MouseEvent) => void;
  onResizeStart:   (e: React.MouseEvent, dir: string) => void;
  onSplitDown:     () => void;
  onSplitLeft:     () => void;
  onAgentDetected: (agent: string | null) => void;
}

export function WorkspaceView({
  runbox, branch, toolbarSlot,
  sidePanel: sidePanelProp,
  sidebarCollapsed = false, fileTreeOpen = false,
  contentMarginLeft = 0,
  onSidePanelToggle, onSidebarToggle, onFileTreeToggle,
  onCwdChange, onSessionChange, onOpenDiff, onOpenFile,
  renderTermPane, renderBrowsePane, renderFileEditor, renderSidePanel,
  onNewWorkspace,
}: WorkspaceViewProps) {
  const areaRef     = useRef<HTMLDivElement>(null);
  const labelCount  = useRef(0);
  const initialized = useRef(false);
  const resizeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const winsRef     = useRef<WinState[]>([]);

  // ── FIX 1: Initialize activeWinId synchronously with the first window ──
  // Previously both setWins and setActiveWinId were called inside a useEffect,
  // causing them to batch as separate renders. On the first render activeWinId
  // was null, so isActive === false, and TerminalPane blurred the xterm textarea
  // immediately — making the terminal appear to not accept keyboard input.
  //
  // By seeding the initial state with the same ID we guarantee that on the very
  // first render activeWinId === wins[0].id → isActive === true → terminal focuses.
  const initialId  = useRef(crypto.randomUUID());
  const initialCwd = runbox.cwd || "~/";

  const [wins, setWins] = useState<WinState[]>([{
    id:        initialId.current,
    label:     "",
    kind:      "terminal",
    x:         GAP,
    y:         GAP,
    w:         800 - GAP * 2,   // will be corrected by ResizeObserver on first paint
    h:         600 - GAP * 2,
    minimized: false,
    maximized: false,
    cwd:       initialCwd,
    zIndex:    nextZ(),
  }]);
  const [activeWinId, setActiveWinId] = useState<string | null>(initialId.current);

  const [fileTabs,      setFileTabs]      = useState<FileTab[]>([]);
  const [activeFileId,  setActiveFileId]  = useState<string | null>(null);
  // Split-right: show file editor to the right of terminals side-by-side
  const [fileSplitRight, setFileSplitRight] = useState(false);
  // Resizable divider for split-right mode
  const [splitRatio, setSplitRatio] = useState(0.5); // 0..1, terminals left portion

  const [_sidePanel, _setSidePanel] = useState<SidePanel>(null);
  const sidePanel    = sidePanelProp !== undefined ? sidePanelProp : _sidePanel;
  // Keep the last opened panel type in a ref so we can leave it mounted (display:none)
  // when the panel is closed — this preserves openPaths diff state inside ChangesTab.
  const lastSidePanelRef = useRef<SidePanel>(null);
  if (sidePanel) lastSidePanelRef.current = sidePanel;
  const mountedPanel: SidePanel = sidePanel ?? lastSidePanelRef.current;
  const [filesView,  setFilesView]  = useState<FilesView>("list");
  // BUG FIX: activeDiff is now a proper DiffTab so the DiffViewer overlay
  // can render independently of whether the side panel is open or closed.
  const [activeDiff, setActiveDiff] = useState<DiffTab | null>(null);
  const [panelWidth, setPanelWidth] = useState(450);
  const [tabCtx,     setTabCtx]     = useState<{ x: number; y: number; win: WinState; idx: number } | null>(null);
  const [pendingBrowserUrl, setPendingBrowserUrl] = useState<Record<string, string | null>>({});
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => { winsRef.current = wins; }, [wins]);

  // Keep a ref to activeWinId so event handlers below don't go stale
  const activeWinIdRef = useRef<string | null>(initialId.current);
  useEffect(() => { activeWinIdRef.current = activeWinId; }, [activeWinId]);

  // Keep a ref to onNewWorkspace so event handlers don't go stale
  const onNewWorkspaceRef = useRef(onNewWorkspace);
  useEffect(() => { onNewWorkspaceRef.current = onNewWorkspace; }, [onNewWorkspace]);

  // Keep a ref to runbox.cwd so closures inside event handlers always read the
  // latest workspace path, not the stale value captured at mount time.
  const runboxCwdRef = useRef(runbox.cwd);
  useEffect(() => { runboxCwdRef.current = runbox.cwd; }, [runbox.cwd]);

  // ── sb: command event bridge ─────────────────────────────────────────────
  useEffect(() => {
    const handle = (e: Event) => {
      const type = (e as CustomEvent).type;
      const aid  = activeWinIdRef.current;

      if (type === "sb:new-terminal") {
        setWins(prev => {
          const area = areaRef.current; if (!area) return prev;
          const aw = area.offsetWidth, ah = area.offsetHeight;
          labelCount.current += 1;
          const id = crypto.randomUUID();
          const activeCwd = prev.find(w => w.id === activeWinIdRef.current)?.cwd || runboxCwdRef.current || runbox.cwd;
          const all: WinState[] = [...prev, { id, label: "", kind: "terminal", x: 0, y: 0, w: 400, h: 300, minimized: false, maximized: false, cwd: activeCwd, zIndex: nextZ() }];
          const visible = all.filter(w => !w.minimized && !w.maximized);
          const tiles   = tileWindows(visible.length, aw, ah);
          let ti = 0;
          const next = all.map(w => w.minimized || w.maximized ? w : { ...w, ...tiles[ti++] });
          setTimeout(() => setActiveWinId(id), 0);
          return next;
        });
        return;
      }

      if ((type === "sb:split-down" || type === "sb:split-right") && aid) {
        const dir = type === "sb:split-down" ? "down" : "left";
        setWins(prev => {
          const src = prev.find(w => w.id === aid); if (!src) return prev;
          const newId = crypto.randomUUID();
          labelCount.current += 1;
          let updated: WinState, newWin: WinState;
          if (dir === "down") {
            const halfH = Math.max(MIN_H, Math.floor((src.h - GAP) / 2));
            updated = { ...src, h: halfH };
            newWin  = { ...src, id: newId, label: "", y: src.y + halfH + GAP, h: src.h - halfH - GAP, zIndex: nextZ(), minimized: false, maximized: false };
          } else {
            const halfW = Math.max(MIN_W, Math.floor((src.w - GAP) / 2));
            updated = { ...src, w: halfW };
            newWin  = { ...src, id: newId, label: "", x: src.x + halfW + GAP, w: src.w - halfW - GAP, zIndex: nextZ(), minimized: false, maximized: false };
          }
          setTimeout(() => setActiveWinId(newId), 0);
          return [...prev.map(w => w.id === aid ? updated : w), newWin];
        });
        return;
      }

      if ((type === "sb:move-terminal-left" || type === "sb:move-terminal-right") && aid) {
        const dir = type === "sb:move-terminal-left" ? "left" : "right";
        setWins(prev => {
          const arr = [...prev];
          const idx = arr.findIndex(w => w.id === aid); if (idx < 0) return prev;
          const newIdx = dir === "left" ? idx - 1 : idx + 1;
          if (newIdx < 0 || newIdx >= arr.length) return prev;
          [arr[idx], arr[newIdx]] = [arr[newIdx], arr[idx]];
          return arr;
        });
        return;
      }

      if (type === "sb:next-terminal" || type === "sb:prev-terminal") {
        const dir = type === "sb:next-terminal" ? 1 : -1;
        setWins(prev => {
          const visible = prev.filter(w => !w.minimized);
          if (visible.length < 2) return prev;
          const idx  = visible.findIndex(w => w.id === activeWinIdRef.current);
          const next = visible[(idx + dir + visible.length) % visible.length];
          if (next) setTimeout(() => { setActiveWinId(next.id); setWins(p => p.map(w => w.id === next.id ? { ...w, zIndex: nextZ() } : w)); }, 0);
          return prev;
        });
        return;
      }

      if (type === "sb:close-terminal" && aid) {
        // Close the currently active (focused) terminal pane
        setWins(prev => {
          const next = prev.filter(w => w.id !== aid);
          if (next.length === 0) { labelCount.current = 0; return next; }
          const area = areaRef.current;
          if (area) {
            const aw = area.offsetWidth, ah = area.offsetHeight;
            const visible = next.filter(w => !w.minimized && !w.maximized);
            const tiles   = tileWindows(visible.length, aw, ah);
            let ti = 0;
            return next.map(w => w.minimized || w.maximized ? w : { ...w, ...tiles[ti++] });
          }
          return next;
        });
        // Focus the most-recently-used remaining pane
        setActiveWinId(prev => {
          if (prev !== aid) return prev;
          const remaining = winsRef.current.filter(w => !w.minimized && w.id !== aid);
          if (remaining.length > 0) {
            const next = remaining[remaining.length - 1];
            setTimeout(() => setActiveWinId(next.id), 0);
          }
          return null;
        });
        return;
      }

      if (type === "sb:new-terminal-workspace") {
        onNewWorkspaceRef.current?.();
        return;
      }

      // ── Spatial pane-focus navigation ──────────────────────────────────
      // sb:focus-pane-up / down / left / right
      // Finds the closest non-minimized pane in the requested direction
      // relative to the active pane, using center-point geometry.
      if (
        type === "sb:focus-pane-up" ||
        type === "sb:focus-pane-down" ||
        type === "sb:focus-pane-left" ||
        type === "sb:focus-pane-right"
      ) {
        const dir =
          type === "sb:focus-pane-up"    ? "up"    :
          type === "sb:focus-pane-down"  ? "down"  :
          type === "sb:focus-pane-left"  ? "left"  : "right";

        const currentWins = winsRef.current.filter(w => !w.minimized);
        const src = currentWins.find(w => w.id === aid);
        if (!src) return;

        const sx = src.x + src.w / 2;
        const sy = src.y + src.h / 2;

        let best: WinState | null = null;
        let bestDist = Infinity;

        for (const w of currentWins) {
          if (w.id === aid) continue;
          const cx = w.x + w.w / 2;
          const cy = w.y + w.h / 2;

          const inDir =
            dir === "up"    ? cy < sy :
            dir === "down"  ? cy > sy :
            dir === "left"  ? cx < sx : cx > sx;

          if (!inDir) continue;

          // Primary: distance along the desired axis
          const primary =
            dir === "up"    ? sy - cy :
            dir === "down"  ? cy - sy :
            dir === "left"  ? sx - cx : cx - sx;

          // Secondary: perpendicular offset — favour direct neighbours
          const perp =
            dir === "up" || dir === "down"
              ? Math.abs(cx - sx)
              : Math.abs(cy - sy);

          const dist = primary + perp * 0.25;
          if (dist < bestDist) { bestDist = dist; best = w; }
        }

        if (best) {
          setActiveWinId(best.id);
          setWins(prev => prev.map(w => w.id === best!.id ? { ...w, zIndex: nextZ() } : w));
        }
        return;
      }

      // ── Minimize / maximize active pane ────────────────────────────────
      if (type === "sb:minimize-terminal" && aid) {
        minimizeWin(aid);
        return;
      }

      if (type === "sb:maximize-terminal" && aid) {
        maximizeWin(aid);
        return;
      }
    };

    const events = [
      "sb:new-terminal",
      "sb:close-terminal",
      "sb:split-down",
      "sb:split-right",
      "sb:move-terminal-left",
      "sb:move-terminal-right",
      "sb:next-terminal",
      "sb:prev-terminal",
      "sb:new-terminal-workspace",
      "sb:focus-pane-up",
      "sb:focus-pane-down",
      "sb:focus-pane-left",
      "sb:focus-pane-right",
      "sb:minimize-terminal",
      "sb:maximize-terminal",
    ];
    events.forEach(ev => window.addEventListener(ev, handle));
    return () => events.forEach(ev => window.removeEventListener(ev, handle));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runbox.cwd]);

  const dispatchResize = useCallback(() => {
    if (resizeTimer.current) clearTimeout(resizeTimer.current);
    resizeTimer.current = setTimeout(() => window.dispatchEvent(new Event("resize")), 80);
  }, []);

  // Mac fullscreen
  useEffect(() => {
    if (!isMac) return;
    getCurrentWindow().isFullscreen().then(setIsFullscreen).catch(() => {});
    const unsub = getCurrentWindow().onResized(async () => {
      try { setIsFullscreen(await getCurrentWindow().isFullscreen()); } catch {}
    });
    return () => { unsub.then(f => f()).catch(() => {}); };
  }, []);

  // ── FIX 1 (cont): Correct initial window geometry on first paint ──
  // The initial wins state uses 800×600 as a placeholder. Once areaRef is
  // attached to the DOM we snap it to the real dimensions immediately.
  useEffect(() => {
    initialized.current = true;
    const area = areaRef.current; if (!area) return;
    const aw = area.offsetWidth || 800, ah = area.offsetHeight || 600;
    labelCount.current = 1;
    setWins(prev => {
      if (prev.length !== 1) return prev; // already multiple windows, don't clobber
      return prev.map(w => ({ ...w, x: GAP, y: GAP, w: aw - GAP * 2, h: ah - GAP * 2, cwd: runboxCwdRef.current || runbox.cwd }));
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Resize observer — retile single visible window
  useEffect(() => {
    const area = areaRef.current; if (!area) return;
    const ro = new ResizeObserver(() => {
      const aw = area.offsetWidth, ah = area.offsetHeight;
      setWins(prev => {
        const visible = prev.filter(w => !w.minimized && !w.maximized);
        if (visible.length !== 1) return prev;
        return prev.map(w => w.minimized || w.maximized ? w : { ...w, x: GAP, y: GAP, w: aw - GAP * 2, h: ah - GAP * 2 });
      });
      setTimeout(() => window.dispatchEvent(new Event("resize")), 50);
    });
    ro.observe(area);
    return () => ro.disconnect();
  }, []);

  // ── BUG FIX: Wire onOpenDiff to open a persistent DiffViewer overlay ──
  // Previously this was a no-op, meaning the diff was only visible while the
  // side panel was open. Now clicking a file in ChangesTab sets activeDiff,
  // which renders a full-height DiffViewer overlay in the content area — so
  // the diff stays visible even after the changes panel is closed.
  useEffect(() => {
    onOpenDiff({
      open: (fc: any) => {
        if (!fc) { setActiveDiff(null); return; }
        const tab: DiffTab = {
          id:          fc.path,
          path:        fc.path,
          diff:        fc.diff ?? "",
          changeType:  fc.change_type ?? "modified",
          insertions:  fc.insertions ?? 0,
          deletions:   fc.deletions ?? 0,
          openedAt:    Date.now(),
        };
        setActiveDiff(tab);
        // Clear active file tab so DiffViewer has full focus
        setActiveFileId(null);
      },
    });
  }, [onOpenDiff]);

  const focusWin = useCallback((id: string) => {
    setActiveWinId(id);
    setWins(prev => prev.map(w => w.id === id ? { ...w, zIndex: nextZ() } : w));
  }, []);

  // Focus next / previous terminal (cycles through non-minimized wins)
  const focusNextWin = useCallback((dir: 1 | -1) => {
    setWins(prev => {
      const visible = prev.filter(w => !w.minimized);
      if (visible.length < 2) return prev;
      setActiveWinId(aid => {
        const idx = visible.findIndex(w => w.id === aid);
        const next = visible[(idx + dir + visible.length) % visible.length];
        if (next) {
          setTimeout(() => focusWin(next.id), 0);
        }
        return aid;
      });
      return prev;
    });
  }, [focusWin]);

  // Wire onOpenFile
  const openFileWin = useCallback((filePath: string) => {
    setFileTabs(prev => {
      const existing = prev.find(t => t.filePath === filePath);
      if (existing) { setActiveFileId(existing.id); return prev; }
      const id = crypto.randomUUID();
      setActiveFileId(id);
      return [...prev, { id, filePath }];
    });
  }, []);

  useEffect(() => { onOpenFile?.({ open: openFileWin }); }, [onOpenFile, openFileWin]);

  // ── BUG FIX: Repaint xterm.js when DiffViewer overlay is dismissed ────────
  // When activeDiff goes null the terminal canvas transitions from opacity:0
  // back to opacity:1. xterm.js canvas elements don't repaint automatically
  // on a CSS opacity change, so we dispatch a resize event to force a flush.
  useEffect(() => {
    if (!activeDiff) {
      const t = setTimeout(() => window.dispatchEvent(new Event("resize")), 80);
      return () => clearTimeout(t);
    }
  }, [activeDiff]);

  const closeFileTab = useCallback((id: string) => {
    setFileTabs(prev => {
      const next = prev.filter(t => t.id !== id);
      setActiveFileId(cur => {
        if (cur !== id) return cur;
        if (next.length === 0) return null;
        const idx = prev.findIndex(t => t.id === id);
        return next[Math.min(idx, next.length - 1)].id;
      });
      if (next.length === 0) setFileSplitRight(false);
      return next;
    });
  }, []);

  // Listen for browser-open-url events
  useEffect(() => {
    const unsub = listen<string>("browser-open-url", ({ payload }) => {
      const url = payload.trim();
      if (!url.startsWith("http") && !url.startsWith("file://")) return;
      const isLocal = url.startsWith("file://") || url.includes("localhost") || url.includes("127.0.0.1") || url.includes("0.0.0.0");
      if (!isLocal) { window.open(url, "_blank"); return; }
      setWins(prev => {
        const existing = prev.find(w => w.kind === "browser");
        if (existing) {
          setPendingBrowserUrl(p => ({ ...p, [existing.id]: url }));
          setActiveWinId(existing.id);
          return prev.map(w => w.id === existing.id ? { ...w, zIndex: nextZ() } : w);
        }
        const area = areaRef.current;
        const id   = crypto.randomUUID();
        setPendingBrowserUrl(p => ({ ...p, [id]: url }));
        setActiveWinId(id);
        return [...prev, { id, label: "browser", kind: "browser" as const, x: GAP, y: GAP, w: area ? area.offsetWidth - GAP * 2 : 800, h: area ? area.offsetHeight - GAP * 2 : 600, minimized: false, maximized: false, cwd: runbox.cwd, zIndex: nextZ() }];
      });
    });
    return () => { unsub.then(f => f()); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runbox.id]);

  const addTerminal = useCallback(() => {
    const area = areaRef.current; if (!area) return;
    const aw = area.offsetWidth, ah = area.offsetHeight;
    labelCount.current += 1;
    const id = crypto.randomUUID();
    setWins(prev => {
      const activeCwd = prev.find(w => w.id === activeWinIdRef.current)?.cwd || runboxCwdRef.current || runbox.cwd;
      const all: WinState[] = [...prev, { id, label: "", kind: "terminal", x: 0, y: 0, w: 400, h: 300, minimized: false, maximized: false, cwd: activeCwd, zIndex: nextZ() }];
      const visible = all.filter(w => !w.minimized && !w.maximized);
      const tiles   = tileWindows(visible.length, aw, ah);
      let ti = 0;
      return all.map(w => w.minimized || w.maximized ? w : { ...w, ...tiles[ti++] });
    });
    setActiveWinId(id);
  }, [runbox.cwd]);

  const closeWin = useCallback((id: string) => {
    const area = areaRef.current;
    setWins(prev => {
      const next = prev.filter(w => w.id !== id);
      if (next.length === 0) { labelCount.current = 0; return next; }
      if (area) {
        const aw = area.offsetWidth, ah = area.offsetHeight;
        const visible = next.filter(w => !w.minimized && !w.maximized);
        const tiles   = tileWindows(visible.length, aw, ah);
        let ti = 0;
        return next.map(w => w.minimized || w.maximized ? w : { ...w, ...tiles[ti++] });
      }
      return next;
    });
    setActiveWinId(prev => {
      if (prev !== id) return prev;
      const remaining = winsRef.current.filter(w => !w.minimized && w.id !== id);
      if (remaining.length > 0) setTimeout(() => setActiveWinId(remaining[remaining.length - 1].id), 0);
      return null;
    });
  }, []);

  const minimizeWin = useCallback((id: string) => {
    setWins(prev => prev.map(w => {
      if (w.id !== id) return w;
      if (w.maximized) return { ...w, maximized: false, x: w.preMaxX ?? GAP, y: w.preMaxY ?? GAP, w: w.preMaxW ?? 400, h: w.preMaxH ?? 300 };
      return { ...w, minimized: true };
    }));
    setActiveWinId(prev => prev === id ? null : prev);
  }, []);

  const restoreWin = useCallback((id: string) => {
    setWins(prev => prev.map(w => w.id === id ? { ...w, minimized: false, zIndex: nextZ() } : w));
    setActiveWinId(id);
    setTimeout(() => window.dispatchEvent(new Event("resize")), 100);
  }, []);

  const maximizeWin = useCallback((id: string) => {
    const area = areaRef.current; if (!area) return;
    const aw = area.offsetWidth, ah = area.offsetHeight;
    setWins(prev => {
      const win = prev.find(w => w.id === id);
      if (!win) return prev;
      if (win.maximized) {
        return prev.map(w => {
          if (w.id === id)
            return { ...w, maximized: false, x: w.preMaxX ?? GAP, y: w.preMaxY ?? GAP, w: w.preMaxW ?? 400, h: w.preMaxH ?? 300 };
          if (w.minimizedByMaximize)
            return { ...w, minimized: false, minimizedByMaximize: false };
          return w;
        });
      }
      return prev.map(w => {
        if (w.id === id)
          return { ...w, maximized: true, preMaxX: win.x, preMaxY: win.y, preMaxW: win.w, preMaxH: win.h, x: 0, y: 0, w: aw, h: ah, zIndex: nextZ() };
        if (!w.minimized)
          return { ...w, minimized: true, minimizedByMaximize: true };
        return w;
      });
    });
    setActiveWinId(id);
    setTimeout(() => window.dispatchEvent(new Event("resize")), 200);
  }, []);

  const moveTab = useCallback((id: string, dir: "left" | "right") => {
    setWins(prev => {
      const arr = [...prev];
      const idx = arr.findIndex(w => w.id === id); if (idx < 0) return prev;
      const newIdx = dir === "left" ? idx - 1 : idx + 1;
      if (newIdx < 0 || newIdx >= arr.length) return prev;
      [arr[idx], arr[newIdx]] = [arr[newIdx], arr[idx]];
      return arr;
    });
  }, []);

  const handleDragStart = useCallback((e: React.MouseEvent, id: string) => {
    e.preventDefault(); focusWin(id);
    const win = winsRef.current.find(w => w.id === id);
    if (!win || win.maximized) return;
    const areaRect = areaRef.current?.getBoundingClientRect();
    if (!areaRect) return;
    const offX = (e.clientX - areaRect.left) - win.x;
    const offY = (e.clientY - areaRect.top)  - win.y;
    const onMove = (ev: MouseEvent) => {
      const rect = areaRef.current?.getBoundingClientRect();
      if (!rect) return;
      setWins(prev => {
        const cur = prev.find(w => w.id === id); if (!cur) return prev;
        const nx = Math.max(0, Math.min(rect.width  - cur.w, (ev.clientX - rect.left) - offX));
        const ny = Math.max(0, Math.min(rect.height - cur.h, (ev.clientY - rect.top)  - offY));
        return prev.map(w => w.id === id ? { ...w, x: nx, y: ny } : w);
      });
    };
    const onUp = () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
    window.addEventListener("mousemove", onMove); window.addEventListener("mouseup", onUp);
  }, [focusWin]);

  const handleResizeStart = useCallback((e: React.MouseEvent, id: string, dir: string) => {
    e.preventDefault(); focusWin(id);
    const win = winsRef.current.find(w => w.id === id);
    if (!win || win.maximized) return;
    const startX = e.clientX, startY = e.clientY;
    const origX = win.x, origY = win.y, origW = win.w, origH = win.h;
    const onMove = (ev: MouseEvent) => {
      const area = areaRef.current;
      const aw = area?.getBoundingClientRect().width  ?? 9999;
      const ah = area?.getBoundingClientRect().height ?? 9999;
      const dx = ev.clientX - startX, dy = ev.clientY - startY;
      let nx = origX, ny = origY, nw = origW, nh = origH;
      if (dir.includes("r")) nw = Math.min(aw - origX, Math.max(MIN_W, origW + dx));
      if (dir.includes("l")) { nw = Math.max(MIN_W, origW - dx); nx = origX + (origW - nw); if (nx < 0) { nw += nx; nx = 0; } }
      if (dir.includes("b")) nh = Math.min(ah - origY, Math.max(MIN_H, origH + dy));
      if (dir.includes("t")) { nh = Math.max(MIN_H, origH - dy); ny = origY + (origH - nh); if (ny < 0) { nh += ny; ny = 0; } }
      setWins(prev => prev.map(w => w.id === id ? { ...w, x: nx, y: ny, w: nw, h: nh } : w));
    };
    const onUp = () => {
      window.dispatchEvent(new Event("resize"));
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove); window.addEventListener("mouseup", onUp);
  }, [focusWin, dispatchResize]);

  // Re-tile on side panel / sidebar changes
  useEffect(() => {
    const area = areaRef.current; if (!area) return;
    const t = setTimeout(() => {
      const aw = area.offsetWidth, ah = area.offsetHeight;
      if (!aw || !ah) return;
      setWins(prev => {
        const visible = prev.filter(w => !w.minimized && !w.maximized);
        if (visible.length === 0) return prev;
        const tiles = tileWindows(visible.length, aw, ah);
        let ti = 0;
        return prev.map(w => w.minimized || w.maximized ? w : { ...w, ...tiles[ti++] });
      });
      window.dispatchEvent(new Event("resize"));
    }, 220);
    return () => clearTimeout(t);
  }, [sidePanel, contentMarginLeft]);

  const splitWin = useCallback((id: string, dir: "down" | "left") => {
    setWins(prev => {
      const src = prev.find(w => w.id === id); if (!src) return prev;
      const newId = crypto.randomUUID();
      labelCount.current += 1;
      let updated: WinState, newWin: WinState;
      if (dir === "down") {
        const halfH = Math.max(MIN_H, Math.floor((src.h - GAP) / 2));
        updated = { ...src, h: halfH };
        newWin  = { ...src, id: newId, label: "", y: src.y + halfH + GAP, h: src.h - halfH - GAP, zIndex: nextZ(), minimized: false, maximized: false };
      } else {
        const halfW = Math.max(MIN_W, Math.floor((src.w - GAP) / 2));
        updated = { ...src, w: halfW };
        newWin  = { ...src, id: newId, label: "", x: src.x + halfW + GAP, w: src.w - halfW - GAP, zIndex: nextZ(), minimized: false, maximized: false };
      }
      setActiveWinId(newId);
      return [...prev.map(w => w.id === id ? updated : w), newWin];
    });
  }, []);

  const reorderWins = useCallback((fromId: string, toId: string) => {
    setWins(prev => {
      const arr = [...prev];
      const fromIdx = arr.findIndex(w => w.id === fromId);
      const toIdx   = arr.findIndex(w => w.id === toId);
      if (fromIdx >= 0 && toIdx >= 0 && fromIdx !== toIdx) {
        const [moved] = arr.splice(fromIdx, 1);
        arr.splice(toIdx, 0, moved);
      }
      return arr;
    });
  }, []);

  // ── Split-right drag divider ─────────────────────────────────────────────
  const handleSplitDividerDrag = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    const container = (e.currentTarget as HTMLElement).parentElement;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const onMove = (ev: MouseEvent) => {
      const ratio = Math.min(0.8, Math.max(0.2, (ev.clientX - rect.left) / rect.width));
      setSplitRatio(ratio);
      setTimeout(() => window.dispatchEvent(new Event("resize")), 30);
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }, []);

  const macOffset     = isMac && !isFullscreen;
  const hasFiles      = fileTabs.length > 0;
  const activeFileTab = fileTabs.find(t => t.id === activeFileId) ?? null;

  const showSplitRight  = fileSplitRight && !!activeFileTab;
  const showFileOverlay = !fileSplitRight && !!activeFileTab;
  // DiffViewer overlay takes priority over terminal canvas when active,
  // but file editor overlay takes priority over diff viewer.
  const showDiffOverlay = !!activeDiff && !showFileOverlay && !showSplitRight;

  // ── Helper: renders the terminal canvas area ─────────────────────────────
  const renderTerminalCanvas = (isActivePredicate: (winId: string) => boolean) => (
    <div ref={areaRef} style={{
      flex: 1, minWidth: 0, minHeight: 0,
      position: "relative", background: C.bg0,
      overflow: "hidden", height: "100%",
      opacity: showFileOverlay || showDiffOverlay ? 0 : 1,
      pointerEvents: showFileOverlay || showDiffOverlay ? "none" : "auto",
      transition: "opacity .1s",
    }}>
      {wins.length === 0 && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16, userSelect: "none", pointerEvents: "none" }}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.55)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>
          </svg>
          <span style={{ fontSize: 18, letterSpacing: "0.06em", color: "rgba(255,255,255,.5)", fontFamily: SANS, fontWeight: 700 }}>Stackbox</span>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 7, marginTop: 4 }}>
            <span style={{ fontSize: 12, color: "rgba(255,255,255,.38)", fontFamily: SANS }}>
              Press <span style={{ fontFamily: MONO, fontSize: 11, background: "rgba(255,255,255,.1)", border: "1px solid rgba(255,255,255,.2)", borderRadius: 4, padding: "1px 8px", color: "rgba(255,255,255,.6)" }}>+</span> to open a terminal
            </span>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,.25)", fontFamily: SANS }}>Split · resize · arrange freely</span>
          </div>
        </div>
      )}

      {wins.map(win => (
        <div key={win.id} style={{
          position: "absolute", left: win.x, top: win.y, width: win.w, height: win.h,
          zIndex: win.zIndex,
          display: win.minimized ? "none" : "flex",
          flexDirection: "column", overflow: "hidden",
          transition: win.maximized ? "left .18s ease, top .18s ease, width .18s ease, height .18s ease" : "none",
        }}>
          {win.kind === "browser"
            ? renderBrowsePane(win, pendingBrowserUrl[win.id] ?? null, () => setPendingBrowserUrl(p => ({ ...p, [win.id]: null })))
            : renderTermPane(win, {
                isActive:    isActivePredicate(win.id),
                onActivate:  () => { setActiveFileId(null); focusWin(win.id); },
                onCwdChange: cwd => {
                  setWins(prev => prev.map(w => w.id === win.id ? { ...w, cwd } : w));
                  onCwdChange(cwd);
                },
                onSessionChange: sid => onSessionChange?.(sid),
                onClose:     () => closeWin(win.id),
                onMinimize:  () => minimizeWin(win.id),
                onMaximize:  () => maximizeWin(win.id),
                onDragStart: e => handleDragStart(e, win.id),
                onResizeStart: (e, dir) => handleResizeStart(e, win.id, dir),
                onSplitDown: () => splitWin(win.id, "down"),
                onSplitLeft: () => splitWin(win.id, "left"),
                onAgentDetected: agent => {
                  setWins(prev => prev.map(w =>
                    w.id === win.id ? { ...w, detectedAgent: agent ?? undefined } : w
                  ));
                },
              })
          }
        </div>
      ))}
    </div>
  );

  return (
    <div style={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, overflow: "hidden" }}>
      <TabBar
        wins={wins}
        fileTabs={fileTabs}
        activeWinId={activeWinId}
        activeFileId={activeFileId}
        sidebarCollapsed={sidebarCollapsed}
        fileTreeOpen={fileTreeOpen}
        macOffset={macOffset}
        toolbarSlot={toolbarSlot}
        fileSplitRight={fileSplitRight}
        onWinActivate={id => { setActiveFileId(null); focusWin(id); }}
        onWinClose={closeWin}
        onWinRestore={restoreWin}
        onAddTerminal={addTerminal}
        onFileSelect={id => setActiveFileId(id)}
        onFileClose={closeFileTab}
        onReorderWins={reorderWins}
        onContextMenu={(e, win, idx) => setTabCtx({ x: e.clientX, y: e.clientY, win, idx })}
        onSidebarToggle={() => onSidebarToggle?.()}
        onFileTreeToggle={() => onFileTreeToggle?.()}
        onFileSplitRight={hasFiles ? () => setFileSplitRight(v => !v) : undefined}
      />

      {/*
        ── FIX 2: Changes panel no longer overlaps terminal ──
        Layout: [terminal area] [side panel]
        Both live as flex siblings inside this row. The side panel pushes the
        terminal area left instead of floating on top of it (position:absolute
        or z-index layering were the old culprits).
        contentMarginLeft moves only the terminal area, not the side panel.
      */}
      <div style={{
        flex: 1, minHeight: 0,
        display: "flex", flexDirection: "row",
        overflow: "hidden",
      }}>

        {/* ── Terminal / editor content area ── */}
        <div style={{
          flex: 1, minWidth: 0, minHeight: 0,
          display: "flex", flexDirection: "column",
          position: "relative", overflow: "hidden",
          marginLeft: contentMarginLeft,
          transition: "margin-left .18s cubic-bezier(.4,0,.2,1)",
        }}>

          {showSplitRight ? (
            /* ── Split-right layout: terminals LEFT | file editor RIGHT ── */
            <div style={{ flex: 1, display: "flex", minHeight: 0, overflow: "hidden" }}>
              {/* Terminals pane (left) */}
              <div style={{
                width: `${splitRatio * 100}%`,
                minWidth: MIN_W,
                flexShrink: 0,
                position: "relative",
                overflow: "hidden",
              }}>
                {renderTerminalCanvas(id => activeWinId === id)}
              </div>

              {/* Drag divider */}
              <div
                onMouseDown={handleSplitDividerDrag}
                style={{
                  width: 4,
                  flexShrink: 0,
                  background: "rgba(255,255,255,.06)",
                  cursor: "col-resize",
                  transition: "background .1s",
                  zIndex: 20,
                }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,229,255,.25)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,.06)"; }}
              />

              {/* File editor pane (right) */}
              <div style={{
                flex: 1,
                minWidth: 280,
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
                background: C.bg0,
                borderLeft: `1px solid ${C.border}`,
              }}>
                {activeFileTab && renderFileEditor(activeFileTab, () => closeFileTab(activeFileTab.id))}
              </div>
            </div>
          ) : (
            /* ── Original layout ── */
            <>
              {/* File editor overlay (fullscreen) — highest priority */}
              {showFileOverlay && activeFileTab && (
                <div style={{ position: "absolute", inset: 0, zIndex: 12, background: C.bg0, display: "flex", flexDirection: "column" }}>
                  {renderFileEditor(activeFileTab, () => closeFileTab(activeFileTab.id))}
                </div>
              )}

              {/* ── BUG FIX: DiffViewer overlay ──────────────────────────────
                  Shown when a file is clicked in ChangesTab and activeDiff is
                  set. Lives independently of the side panel so it stays visible
                  even after the changes panel is closed.
                  Clicking "Files" in DiffViewer's header clears activeDiff.     */}
              {showDiffOverlay && activeDiff && (
                <div style={{
                  position: "absolute", inset: 0, zIndex: 11,
                  display: "flex", flexDirection: "column",
                  background: C.bg0,
                  animation: "slideIn .12s ease",
                }}>
                  <DiffViewer
                    tab={activeDiff}
                    onClose={() => setActiveDiff(null)}
                  />
                </div>
              )}

              {/* Window canvas — terminals */}
              {renderTerminalCanvas(id => activeWinId === id && !showFileOverlay && !showDiffOverlay)}
            </>
          )}
        </div>

        {/* Side panel — kept mounted so diff open-state survives close/reopen.
            Uses display:flex/none instead of conditional rendering. */}
        {mountedPanel && (
          <div style={{
            width: panelWidth,
            flexShrink: 0,
            display: sidePanel ? "flex" : "none",
            alignItems: "stretch",
            borderLeft: `1px solid ${C.border}`,
          }}>
            <ResizeHandle onResize={w => setPanelWidth(w)} />
            <div style={{
              flex: 1, minWidth: 0,
              display: "flex", flexDirection: "column",
              background: C.bg1, overflow: "hidden",
              boxShadow: "-4px 0 24px rgba(0,0,0,.35)",
            }}>
              {renderSidePanel(mountedPanel, runbox, branch, () => {
                // ── BUG FIX: clear DiffViewer overlay on panel close ──────────
                // Without this, activeDiff stays set → showDiffOverlay stays
                // true → terminal canvas stays opacity:0 → looks fully blank
                // after the side panel slides away.
                setActiveDiff(null);
                onSidePanelToggle?.(mountedPanel as any);
              })}
            </div>
          </div>
        )}
      </div>

      {tabCtx && (
        <TabContextMenu
          x={tabCtx.x} y={tabCtx.y} win={tabCtx.win}
          isFirst={tabCtx.idx === 0} isLast={tabCtx.idx === wins.length - 1}
          onClose={() => setTabCtx(null)}
          onCloseTab={() => closeWin(tabCtx.win.id)}
          onRestore={tabCtx.win.minimized ? () => restoreWin(tabCtx.win.id) : undefined}
          onMoveLeft={() => moveTab(tabCtx.win.id, "left")}
          onMoveRight={() => moveTab(tabCtx.win.id, "right")}
          onNewTerminal={addTerminal}
          onSplitDown={() => splitWin(tabCtx.win.id, "down")}
          onSplitRight={() => splitWin(tabCtx.win.id, "left")}
          onNextTerminal={() => focusNextWin(1)}
          onPrevTerminal={() => focusNextWin(-1)}
          onOpenChanges={() => { onSidePanelToggle?.("git"); setTabCtx(null); }}
          onNewWorkspace={onNewWorkspace ? () => { onNewWorkspace(); setTabCtx(null); } : undefined}
        />
      )}

      <style>{`
        @keyframes slideIn { from { opacity:0; transform:translateX(10px); } to { opacity:1; transform:translateX(0); } }
        @keyframes sp { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}