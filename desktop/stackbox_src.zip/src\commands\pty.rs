// src-tauri/src/commands/pty.rs
use std::io::Write;
use tauri::AppHandle;
use crate::{
    agent::kind::AgentKind,
    db::sessions::session_end,
    git::repo::remove_worktree,
    pty::{self, expand_cwd},
    state::AppState,
};

#[tauri::command]
pub async fn pty_spawn(
    app:        AppHandle,
    session_id: String,
    runbox_id:  String,
    cwd:        String,
    agent_cmd:  Option<String>,
    cols:       Option<u16>,
    rows:       Option<u16>,
    state:      tauri::State<'_, AppState>,
) -> Result<(), String> {
    pty::spawn(app, session_id, runbox_id, cwd, agent_cmd, cols, rows, &state).await
}

#[tauri::command]
pub fn pty_write(
    session_id: String,
    data:       String,
    state:      tauri::State<'_, AppState>,
) -> Result<(), String> {
    let mut inject:    Option<(String, String, AgentKind)> = None;
    let mut open_url:  Option<String> = None;
    let mut send_data: Option<String> = None; // override what gets sent to the PTY

    {
        let mut sessions = state.sessions.lock().unwrap();
        if let Some(s) = sessions.get_mut(&session_id) {
            // ── Process chars into input_buf BEFORE writing to PTY ────────────
            // This lets us intercept commands (e.g. `start .\index.html`) and
            // decide what to actually send to the shell.
            for ch in data.chars() {
                match ch {
                    '\r' | '\n' => {
                        let line = s.input_buf.trim().to_string();
                        s.input_buf.clear();
                        if !line.is_empty() {
                            // ── `start <html-file>` interception ───────────────
                            // On Windows, `start .\index.html` opens the system
                            // browser, bypassing our BROWSER shim. We intercept
                            // it here, send Ctrl+C to abort the command, and emit
                            // browser-open-url so the built-in browser opens it.
                            if let Some(url) = intercept_start_cmd(&line, &s.cwd) {
                                open_url  = Some(url);
                                // Ctrl+C cancels the typed command + newline to
                                // return to a clean prompt. The `start` command
                                // is never executed.
                                send_data = Some("\x03\r\n".to_string());
                            } else {
                                let token    = line.split_whitespace().next().unwrap_or("");
                                let base_cmd = token.rsplit(['/', '\\']).next().unwrap_or(token);
                                let kind     = AgentKind::detect(base_cmd);
                                if kind != AgentKind::Shell {
                                    inject = Some((s.runbox_id.clone(), s.cwd.clone(), kind));
                                }
                            }
                        }
                    }
                    '\x08' | '\x7f' => { s.input_buf.pop(); }
                    c if !c.is_control() => { s.input_buf.push(c); }
                    _ => {}
                }
            }

            // Write either the override or the original data
            let to_write = send_data.as_deref().unwrap_or(&data);
            let _ = s.writer.write_all(to_write.as_bytes());
            let _ = s.writer.flush();
        }
    }

    // Emit browser open event outside the lock
    if let Some(url) = open_url {
        crate::agent::globals::emit_event("browser-open-url", serde_json::json!(url));
    }

    if let Some((rb, cwd, kind)) = inject {
        let sid = session_id.clone();
        let db  = state.db.clone();
        tauri::async_runtime::spawn(async move {
            if let Err(e) = crate::agent::context::inject(&db, &rb, &sid, &cwd, &kind).await {
                eprintln!("[pty_write] re-inject: {e}");
            }
        });
    }
    Ok(())
}

/// If `line` looks like `start <path-to-html-file>`, return the `file://` URL.
/// Returns None for any other command so normal execution continues.
fn intercept_start_cmd(line: &str, cwd: &str) -> Option<String> {
    // Split into command + remainder (handles extra spaces)
    let mut parts = line.splitn(2, char::is_whitespace);
    let cmd = parts.next().unwrap_or("").to_lowercase();
    if cmd != "start" { return None; }

    // Strip surrounding quotes — PowerShell and cmd both accept them
    let arg = parts.next()?.trim().trim_matches('"').trim_matches('\'');
    if arg.is_empty() { return None; }

    // Only intercept web/html files
    let lower = arg.to_lowercase();
    if !lower.ends_with(".html") && !lower.ends_with(".htm")
        && !lower.ends_with(".svg")  && !lower.ends_with(".pdf") {
        return None;
    }

    // Already a file:// URL — pass through as-is
    if arg.starts_with("file://") { return Some(arg.to_string()); }

    // Absolute Windows path: C:\Users\...
    if arg.len() >= 2 && arg.chars().nth(1) == Some(':') {
        let normalised = arg.replace('\\', "/");
        return Some(format!("file:///{normalised}"));
    }

    // Relative path — resolve against the session's cwd
    let abs = std::path::Path::new(cwd).join(arg);

    // canonicalize gives us the real absolute path with spaces etc. intact
    if let Ok(canonical) = abs.canonicalize() {
        // url::Url::from_file_path handles percent-encoding of spaces
        if let Ok(url) = url::Url::from_file_path(&canonical) {
            return Some(url.to_string());
        }
        // Fallback — build manually
        let s = canonical.to_string_lossy().replace('\\', "/");
        return Some(format!("file:///{}", s.trim_start_matches('/')));
    }

    // File doesn't exist yet — build the URL anyway (agent may be creating it)
    let s = abs.to_string_lossy().replace('\\', "/");
    Some(format!("file:///{}", s.trim_start_matches('/')))
}

#[tauri::command]
pub fn pty_resize(
    session_id: String, cols: u16, rows: u16,
    state: tauri::State<'_, AppState>,
) -> Result<(), String> {
    use portable_pty::PtySize;
    if let Some(s) = state.sessions.lock().unwrap().get(&session_id) {
        s._master.resize(PtySize { rows, cols, pixel_width: 0, pixel_height: 0 })
            .map_err(|e| e.to_string())?;
    }
    Ok(())
}

#[tauri::command]
pub fn pty_kill(session_id: String, state: tauri::State<'_, AppState>) -> Result<(), String> {
    if let Some(mut s) = state.sessions.lock().unwrap().remove(&session_id) {
        let _ = s._child.kill();
        let _ = session_end(&state.db, &session_id, Some(1), None);
        if let Some(ref wt) = s.worktree_path {
            remove_worktree(wt);
        }
    }
    Ok(())
}